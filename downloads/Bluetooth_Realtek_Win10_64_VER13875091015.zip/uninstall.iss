[InstallShield Silent]
Version=v7.00
File=Response File
[File Transfer]
OverwrittenReadOnly=NoToAll
[{E9EE4026-36ED-4E40-AB80-BCA6FFB31842}-DlgOrder]
Dlg0={E9EE4026-36ED-4E40-AB80-BCA6FFB31842}-AskYesNo-0
Count=2
Dlg1={E9EE4026-36ED-4E40-AB80-BCA6FFB31842}-SdFinish-0
[{E9EE4026-36ED-4E40-AB80-BCA6FFB31842}-AskYesNo-0]
Result=1
[{E9EE4026-36ED-4E40-AB80-BCA6FFB31842}-SdFinish-0]
Result=1
bOpt1=0
bOpt2=0
